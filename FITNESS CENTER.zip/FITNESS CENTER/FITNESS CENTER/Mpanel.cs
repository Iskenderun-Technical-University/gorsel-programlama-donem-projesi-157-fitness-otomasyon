﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FITNESS_CENTER
{
    public partial class Mpanel : Form
    {
        public Mpanel()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ADDMEM addmember = new ADDMEM();
            new ADDMEM().Show();
            this.Hide();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
           UpdateDelete Update = new UpdateDelete();
            Update.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new UpdateDelete().Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
           Payment pay = new Payment();
            pay.Show();    
            this.Hide();
        }

        private void Mpanel_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            ViewMembers viewmember = new ViewMembers();
            viewmember.Show();
            this.Hide();
        }
    }
}
