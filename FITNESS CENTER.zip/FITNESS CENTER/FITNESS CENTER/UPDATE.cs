﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FITNESS_CENTER
{
    public partial class UPDATE : Form
    {
        public UPDATE()
        {
            InitializeComponent();
        }

        private void UPDATE_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Mpanel().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Mpanel().Show();
            this.Hide();
        }
    }
}
