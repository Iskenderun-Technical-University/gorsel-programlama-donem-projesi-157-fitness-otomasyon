﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FITNESS_CENTER
{
    public partial class ViewMembers : Form
    {
        public ViewMembers()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login log = new Login ();
            log.Show();
            this.Hide();

        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        
        SqlConnection Con = new SqlConnection(@"Data Source=ASSEM\SQLEXPRESS;Initial Catalog=gymD;Integrated Security=True");
        private void Populate()
        {
            Con.Open();
            string query = "select * from MemberTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            MemberSDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void MemberSdGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void ViewMembers_Load(object sender, EventArgs e)
        {
            Populate();

        }
        private void filterByName()
        {
            Con.Open();
            string query = "select * from MemberTbl where MName='" + SearchMember.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            MemberSDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            filterByName();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Populate();
        }
    }
}
